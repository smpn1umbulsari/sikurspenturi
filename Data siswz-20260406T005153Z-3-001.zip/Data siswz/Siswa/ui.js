// ================= FORM =================
function renderForm() {
  return `
    <div class="card" style="max-width:500px">

      <h2 style="margin-bottom:20px">Input Data Siswa</h2>

      <div class="form-group">
        <input id="nipd" placeholder="NIPD" oninput="validateForm()">
        <div id="err-nipd" class="error-text"></div>
      </div>

      <div class="form-group">
        <input id="nisn" placeholder="NISN (10 digit)" oninput="validateForm()">
        <div id="err-nisn" class="error-text"></div>
      </div>

      <div class="form-group">
        <input id="nama" placeholder="Nama Siswa" oninput="validateForm()">
        <div id="err-nama" class="error-text"></div>
      </div>

      <div class="form-group">
        <select id="jk" onchange="validateForm()">
          <option value="">Jenis Kelamin</option>
          <option value="L">Laki-laki</option>
          <option value="P">Perempuan</option>
        </select>
      </div>

      <div class="form-group">
        <select id="agama">
          <option value="">Agama</option>
          <option>Islam</option>
          <option>Kristen</option>
          <option>Katolik</option>
          <option>Hindu</option>
          <option>Buddha</option>
          <option>Konghucu</option>
        </select>
      </div>

      <div class="form-group">
        <input id="kelas" placeholder="Kelas (contoh: 7A)">
      </div>

      <button id="btnSimpan" class="btn-primary" onclick="simpanData()">
        Simpan Data
      </button>

    </div>
  `;
}


// ================= TABLE =================
function renderTable() {
  return `
    <div class="card">

      <h2>Data Siswa</h2>

      <!-- TOOLBAR -->
      <div class="toolbar">

        <!-- SEARCH -->
        <div class="toolbar-left">
          <input id="search" placeholder="🔍 Cari siswa..." oninput="handleSearch(); updateFilterUI()">
        </div>

        <!-- FILTER + ACTION -->
        <div class="toolbar-right">

          <select id="filterJK" onchange="renderFiltered(); updateFilterUI()">
            <option value="">Semua JK</option>
            <option value="L">Laki-laki</option>
            <option value="P">Perempuan</option>
          </select>

          <select id="filterAgama" onchange="renderFiltered(); updateFilterUI()">
            <option value="">Semua Agama</option>
            <option>Islam</option>
            <option>Kristen</option>
            <option>Katolik</option>
            <option>Hindu</option>
            <option>Buddha</option>
            <option>Konghucu</option>
          </select>

          <label class="btn-upload">
            Import
            <input type="file" accept=".xlsx, .xls" onchange="importExcel(event)">
          </label>

          <button class="btn-secondary" onclick="resetFilter()">Reset</button>

        </div>
      </div>

      <!-- INFO -->
      <div class="toolbar-info">
        <span id="jumlahData">0 siswa</span>
      </div>

      <!-- TABLE -->
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>NIPD</th>
              <th>NISN</th>
              <th>Nama</th>
              <th>JK</th>
              <th>Agama</th>
              <th>Kelas</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody id="tbody"></tbody>
        </table>

        <!-- EMPTY STATE -->
        <div id="emptyState" style="display:none; text-align:center; padding:20px; color:#64748b;">
          Tidak ada data
        </div>
      </div>

      <!-- 🔥 WAJIB UNTUK IMPORT -->
      <div id="previewContainer" class="card" style="display:none; margin-top:20px;"></div>

    </div>
  `;
}


// ================= ROW =================
function renderRow(d) {

  if (currentEdit === d.nipd) {
    return `
      <tr>
        <td>${d.nipd}</td>
        <td><input id="nisn-${d.nipd}" value="${d.nisn || ""}"></td>
        <td><input id="nama-${d.nipd}" value="${d.nama}"></td>

        <td>
          <select id="jk-${d.nipd}">
            <option value="L" ${d.jk==="L"?"selected":""}>L</option>
            <option value="P" ${d.jk==="P"?"selected":""}>P</option>
          </select>
        </td>

        <td>
          <select id="agama-${d.nipd}">
            ${renderAgamaOptions(d.agama)}
          </select>
        </td>

        <td><input id="kelas-${d.nipd}" value="${d.kelas || ""}"></td>

        <td>
          <button onclick="saveEdit('${d.nipd}')" class="btn-primary">✔</button>
          <button onclick="cancelEdit()" class="btn-secondary">✖</button>
        </td>
      </tr>
    `;
  }

  return `
    <tr>
      <td>${d.nipd || "-"}</td>
      <td>${d.nisn || "-"}</td>
      <td>${d.nama || "-"}</td>
      <td>${d.jk || "-"}</td>
      <td>${d.agama || "-"}</td>
      <td>${d.kelas || "-"}</td>
      <td>

        ${d.nipd ? `
          <button class="btn-primary" onclick="editRow('${d.nipd}')">
            Edit
          </button>
        ` : `
          <button class="btn-secondary" disabled>
            Edit
          </button>
        `}

        <button class="btn-danger" onclick="hapusData('${d.nipd}')">
          Hapus
        </button>

      </td>
    </tr>
  `;
}


// ================= HELPER =================
function renderAgamaOptions(selected) {
  const list = ["Islam","Kristen","Katolik","Hindu","Buddha","Konghucu"];
  return list.map(a =>
    `<option ${a===selected?"selected":""}>${a}</option>`
  ).join("");
}
// ================= STATE =================
let semuaData = [];
let currentEdit = null;
let unsubscribe = null;
let isSubmitting = false;
let debounce;


// ================= LOAD =================
function loadRealtime() {
  if (unsubscribe) unsubscribe();

  unsubscribe = listenSiswa(data => {
    semuaData = data;
    renderFiltered();
  });
}


// ================= FILTER =================
function renderFiltered() {

  const keyword = document.getElementById("search")?.value?.toLowerCase() || "";
  const jk = document.getElementById("filterJK")?.value || "";
  const agama = document.getElementById("filterAgama")?.value || "";

  const hasil = semuaData.filter(d =>
    (
      (d.nama || "").toLowerCase().includes(keyword) ||
      (d.nipd || "").toLowerCase().includes(keyword)
    ) &&
    (!jk || (d.jk || "").toUpperCase() === jk) &&
    (!agama || (d.agama || "").toLowerCase() === agama.toLowerCase())
  );

  const tbody = document.getElementById("tbody");
  const empty = document.getElementById("emptyState");

  if (!tbody) return;

  tbody.innerHTML = hasil.map(renderRow).join("");

  // 🔥 EMPTY STATE
  if (empty) {
    empty.style.display = hasil.length === 0 ? "block" : "none";
  }

  // 🔥 JUMLAH DATA
  const info = document.getElementById("jumlahData");
  if (info) {
    info.innerText = `${hasil.length} siswa`;
  }
}


// ================= SEARCH =================
function handleSearch() {
  clearTimeout(debounce);
  debounce = setTimeout(renderFiltered, 300);
}


// ================= RESET FILTER =================
function resetFilter() {
  document.getElementById("search").value = "";
  document.getElementById("filterJK").value = "";
  document.getElementById("filterAgama").value = "";

  renderFiltered();
}


// ================= SIMPAN =================
async function simpanData() {

  if (isSubmitting) return;
  if (!validateForm()) return;

  const btn = document.getElementById("btnSimpan");

  // 🔥 AMAN
  const nipdEl = document.getElementById("nipd");
  const nisnEl = document.getElementById("nisn");
  const namaEl = document.getElementById("nama");
  const jkEl = document.getElementById("jk");
  const agamaEl = document.getElementById("agama");
  const kelasEl = document.getElementById("kelas");

  const data = {
    nipd: nipdEl.value.trim(),
    nisn: nisnEl.value.trim(),
    nama: namaEl.value.trim(),
    jk: jkEl.value,
    agama: agamaEl.value,
    kelas: kelasEl.value.trim(),
    created_at: new Date()
  };

  try {
    isSubmitting = true;

    if (btn) {
      btn.disabled = true;
      btn.innerText = "Menyimpan...";
    }

    await saveSiswa(data);

    Swal.fire("Berhasil", "", "success");

    // 🔥 RESET FORM
    nipdEl.value = "";
    nisnEl.value = "";
    namaEl.value = "";
    jkEl.value = "";
    agamaEl.value = "";
    kelasEl.value = "";

  } catch {
    Swal.fire("Gagal", "", "error");
  } finally {
    isSubmitting = false;

    if (btn) {
      btn.disabled = false;
      btn.innerText = "Simpan Data";
    }
  }
}


// ================= DELETE =================
async function hapusData(nipd) {

  const confirm = await Swal.fire({
    title: "Hapus data?",
    showCancelButton: true
  });

  if (!confirm.isConfirmed) return;

  await deleteSiswa(nipd);
}


// ================= EDIT =================
function editRow(nipd) {
  currentEdit = nipd;
  renderFiltered();
}


// ================= CANCEL EDIT =================
function cancelEdit() {
  currentEdit = null;
  renderFiltered();
}


// ================= SAVE EDIT =================
async function saveEdit(nipd) {

  const nisn = document.getElementById(`nisn-${nipd}`).value.trim();
  const nama = document.getElementById(`nama-${nipd}`).value.trim();
  const jk = document.getElementById(`jk-${nipd}`).value;
  const agama = document.getElementById(`agama-${nipd}`).value;
  const kelas = document.getElementById(`kelas-${nipd}`).value.trim();

  // 🔥 VALIDASI SEDERHANA
  if (!nisn || nisn.length !== 10) {
    Swal.fire("NISN harus 10 digit");
    return;
  }

  if (!nama) {
    Swal.fire("Nama tidak boleh kosong");
    return;
  }

  try {
    await updateSiswa(nipd, {
      nisn,
      nama,
      jk,
      agama,
      kelas,
      updated_at: new Date()
    });

    currentEdit = null;
    renderFiltered();

    Swal.fire("Update berhasil", "", "success");

  } catch {
    Swal.fire("Gagal update", "", "error");
  }
}
// =====================================================
// SMART IMPORT EXCEL (PRO VERSION)
// =====================================================

let previewData = [];
let lastImportedIds = [];
let isUploading = false;


// =====================================================
// STEP 1: IMPORT FILE
// =====================================================
function importExcel(e) {

  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();

  reader.onload = (evt) => {
    try {
      const data = new Uint8Array(evt.target.result);
      const workbook = XLSX.read(data, { type: "array" });

      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json(sheet);

      previewData = json.map(row => {

        const nipd = String(row.NIPD || "").trim();
        const nisn = String(row.NISN || "").trim();
        const nama = String(row.NAMA_SISWA || "").trim();
        const jk = String(row.JK || "").trim();
        const agama = String(row.Agama || "").trim();
        const kelas = String(row.KELAS || "").trim();

        const existing = semuaData.find(d => d.nipd === nipd);
        const nisnConflict = semuaData.find(d => d.nisn === nisn && d.nipd !== nipd);

        let status = "new";

        if (!nipd || !nisn || !nama) {
          status = "error";
        } else if (nisnConflict) {
          status = "conflict";
        } else if (existing) {

          const isSame =
            existing.nama === nama &&
            existing.nisn === nisn &&
            existing.jk === jk &&
            existing.agama === agama &&
            existing.kelas === kelas;

          status = isSame ? "same" : "update";
        }

        return {
          nipd, nisn, nama, jk, agama, kelas,
          status,
          existing
        };
      });

      renderPreview();

    } catch (err) {
      console.error(err);
      Swal.fire("Gagal membaca file", "", "error");
    }
  };

  reader.readAsArrayBuffer(file);
}


// =====================================================
// STEP 2: PREVIEW
// =====================================================
function renderPreview() {

  const container = document.getElementById("previewContainer");
  if (!container) return;

  container.style.display = "block";

  const summary = {
    new: previewData.filter(d => d.status === "new").length,
    update: previewData.filter(d => d.status === "update").length,
    same: previewData.filter(d => d.status === "same").length,
    conflict: previewData.filter(d => d.status === "conflict").length,
    error: previewData.filter(d => d.status === "error").length
  };

  const rows = previewData.slice(0, 20).map(d => {

    let bg = "", label = "";

    switch (d.status) {
      case "error":
        bg = "#fee2e2"; label = "ERROR"; break;
      case "conflict":
        bg = "#fde68a"; label = "CONFLICT"; break;
      case "update":
        bg = "#bfdbfe"; label = "UPDATE"; break;
      case "new":
        bg = "#dcfce7"; label = "NEW"; break;
      case "same":
        bg = "#f1f5f9"; label = "SAME"; break;
    }

    return `
      <tr style="background:${bg}">
        <td>${d.nipd}</td>
        <td>${d.nisn}</td>
        <td>${d.nama}</td>
        <td>${d.jk}</td>
        <td>${d.agama}</td>
        <td>${d.kelas}</td>
        <td><b>${label}</b></td>
      </tr>
    `;
  }).join("");

  container.innerHTML = `
    <h3>Preview (${previewData.length} data)</h3>

    <div style="margin:10px 0; font-size:13px;">
      🟢 Baru: ${summary.new} |
      🔵 Update: ${summary.update} |
      ⚪ Same: ${summary.same} |
      🟡 Conflict: ${summary.conflict} |
      🔴 Error: ${summary.error}
    </div>

    <table>
      <thead>
        <tr>
          <th>NIPD</th>
          <th>NISN</th>
          <th>Nama</th>
          <th>JK</th>
          <th>Agama</th>
          <th>Kelas</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>

    <div style="margin:10px 0;">
      <b>Mode Import:</b><br>

      <label>
        <input type="radio" name="importMode" value="update" checked>
        Update (ubah jika berbeda)
      </label><br>

      <label>
        <input type="radio" name="importMode" value="skip">
        Skip (lewati data lama)
      </label><br>

      <label>
        <input type="radio" name="importMode" value="overwrite">
        Overwrite (paksa semua)
      </label>
    </div>

    <div style="margin-top:15px; display:flex; gap:10px;">
      <button class="btn-primary" onclick="uploadImport()">Upload</button>
      <button class="btn-secondary" onclick="batalImport()">Batal</button>
    </div>

    <small>
      Hijau=baru | Biru=update | Abu=same | Kuning=conflict | Merah=error
    </small>
  `;
}


// =====================================================
// STEP 3: MODE
// =====================================================
function getImportMode() {
  return document.querySelector('input[name="importMode"]:checked')?.value || "update";
}


// =====================================================
// STEP 4: UPLOAD
// =====================================================
async function uploadImport() {

  if (isUploading) return;
  isUploading = true;

  let berhasil = 0;
  let gagal = 0;

  lastImportedIds = [];

  Swal.fire({
    title: "Mengupload...",
    didOpen: () => Swal.showLoading()
  });

  const mode = getImportMode();

  for (const d of previewData) {

    if (d.status === "error" || d.status === "conflict") {
      gagal++;
      continue;
    }

    const exists = !!d.existing;

    try {

      if (mode === "skip" && exists) continue;

      if (mode === "update" && exists && d.status === "same") continue;

      await db.collection("siswa").doc(d.nipd).set({
        nipd: d.nipd,
        nisn: d.nisn,
        nama: d.nama,
        jk: d.jk,
        agama: d.agama,
        kelas: d.kelas,
        created_at: exists ? d.existing.created_at || new Date() : new Date(),
        updated_at: new Date()
      });

      if (!exists) {
        lastImportedIds.push(d.nipd);
      }

      berhasil++;

    } catch (err) {
      console.error(err);
      gagal++;
    }
  }

  document.getElementById("previewContainer").style.display = "none";

  Swal.fire({
    title: "Import selesai",
    html: `Berhasil: ${berhasil}<br>Gagal: ${gagal}`,
    showCancelButton: true,
    confirmButtonText: "Undo",
    cancelButtonText: "Tutup"
  }).then(res => {
    if (res.isConfirmed) undoImport();
  });

  isUploading = false;
}


// =====================================================
// STEP 5: UNDO (DATA BARU)
// =====================================================
async function undoImport() {

  Swal.fire({
    title: "Undo...",
    didOpen: () => Swal.showLoading()
  });

  for (const id of lastImportedIds) {
    await db.collection("siswa").doc(id).delete();
  }

  Swal.fire("Undo berhasil", "", "success");
}


// =====================================================
// STEP 6: BATAL
// =====================================================
function batalImport() {
  previewData = [];
  document.getElementById("previewContainer").style.display = "none";
}
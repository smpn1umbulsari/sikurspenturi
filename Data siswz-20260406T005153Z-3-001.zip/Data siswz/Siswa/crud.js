// ================= FIRESTORE CRUD =================

async function saveSiswa(data) {
  return db.collection("siswa").doc(data.nipd).set(data);
}

async function updateSiswa(nipd, data) {
  return db.collection("siswa").doc(nipd).update(data);
}

async function deleteSiswa(nipd) {
  return db.collection("siswa").doc(nipd).delete();
}

function listenSiswa(callback) {
  return db.collection("siswa")
    .orderBy("nama")
    .onSnapshot(snapshot => {
      const data = snapshot.docs.map(doc => doc.data());
      callback(data);
    });
}